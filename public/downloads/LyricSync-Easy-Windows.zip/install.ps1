﻿$ErrorActionPreference='Stop'
$base=Join-Path $env:LOCALAPPDATA 'LyricSync-Easy'
function run($exe,[string[]]$argv){ & $exe @argv; if($LASTEXITCODE -ne 0){throw "処理に失敗しました: $exe ($LASTEXITCODE)"} }
function findPython {
  $reg='Software\Python\PythonCore\3.10\InstallPath'
  foreach($key in "HKCU:\$reg","HKLM:\$reg"){
    if(Test-Path $key){$p=Join-Path (Get-Item $key).GetValue('') 'python.exe'; if(Test-Path $p){return $p}}
  }
}
try {
  if($env:PROCESSOR_ARCHITECTURE -ne 'AMD64'){throw '64ビットのIntel/AMD版Windowsで実行してください。'}
  New-Item -Type Directory -Force $base | Out-Null
  Start-Transcript -Path (Join-Path $base 'setup.log') -Force | Out-Null
  $py=Join-Path $base 'venv\Scripts\python.exe'
  if(!(Test-Path $py)){
    $runtime=findPython
    if(!$runtime){
      if(!(Get-Command winget.exe -ErrorAction SilentlyContinue)){throw 'Microsoft Store の「アプリ インストーラー」を更新後、再実行してください。'}
      Write-Host 'Python 3.10 をこのユーザー向けに準備します。'
      run winget.exe @('install','--id','Python.Python.3.10','--exact','--source','winget','--scope','user','--architecture','x64','--accept-package-agreements','--accept-source-agreements')
      $runtime=findPython
    }
    if(!$runtime){throw 'Python 3.10 を検出できません。Windowsに再サインインし、再実行してください。'}
    run $runtime @('-m','venv',(Join-Path $base 'venv'))
  }
  Write-Host '音声処理に必要なファイルを取得します。初回は時間がかかります。'
  $index='cpu'
  if(Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue){$index='cu121'}
  run $py @('-m','pip','install','--upgrade','pip')
  run $py @('-m','pip','install','torch==2.5.1','torchaudio==2.5.1','--index-url',"https://download.pytorch.org/whl/$index")
  run $py @('-m','pip','install','imageio-ffmpeg==0.6.0',(Join-Path $PSScriptRoot 'package'))
  $ff=& $py -c "from imageio_ffmpeg import get_ffmpeg_exe; print(get_ffmpeg_exe())"
  if($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $ff)){throw 'FFmpegを取得できませんでした。'}
  $env:LYRICSYNC_FFMPEG=Join-Path $base 'venv\Scripts\ffmpeg.exe'
  Copy-Item -LiteralPath $ff -Destination $env:LYRICSYNC_FFMPEG -Force
  run $py @((Join-Path $PSScriptRoot 'check.py'))
  run $py @((Join-Path $PSScriptRoot 'package\tests\test_lyrics.py'))
  Copy-Item (Join-Path $PSScriptRoot 'start.pyw') $base -Force
  $desktop=[Environment]::GetFolderPath('DesktopDirectory')
  $link=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'LyricSync Easy.lnk'))
  $link.TargetPath=Join-Path $base 'venv\Scripts\pythonw.exe'
  $link.Arguments='"'+(Join-Path $base 'start.pyw')+'"'
  $link.WorkingDirectory=$base
  $link.Save()
  Write-Host '準備ができました。デスクトップの LyricSync Easy を開いてください。'
  Stop-Transcript | Out-Null
} catch {Write-Host $_ -ForegroundColor Red; Write-Host "ログ: $base\setup.log"; exit 1}
