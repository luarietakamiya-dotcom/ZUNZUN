import tempfile, wave
from pathlib import Path
from lyricsync.audio import load_audio
import lyricsync.server, demucs, stable_whisper, torchaudio, pystray
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "sample.wav"
    with wave.open(str(path), "wb") as w:
        w.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
        w.writeframes(bytes(32000))
    assert load_audio(path, 16000).shape == (1, 16000)
print("Audio decode: OK")
