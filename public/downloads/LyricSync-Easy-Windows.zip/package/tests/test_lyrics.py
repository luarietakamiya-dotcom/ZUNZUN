"""歌詞の行番号が ZUNZUN / JIZURA と一致するかのテスト。

parse_expected_zunzun.json は ZUNZUN の src/core/lyrics/parse.ts (2026-11-08 の版、071e582 以降。parseLyrics(stripBracketNotes(...)))
を esbuild でまとめて node で実行し、parse_cases.json の各入力に対して得た結果。
行ごとに [text, src, lrc, interlude, secs]。

  python tests/test_lyrics.py
"""

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from lyricsync.lyrics import parse_lyrics, read_lyrics, srt_to_lrc, strip_bracket_notes  # noqa: E402


def test_matches_zunzun() -> None:
    cases = json.loads((HERE / "parse_cases.json").read_text(encoding="utf-8"))
    expected = json.loads((HERE / "parse_expected_zunzun.json").read_text(encoding="utf-8"))
    for i, (src, exp) in enumerate(zip(cases, expected)):
        got = [[l.text, l.src, l.lrc, l.interlude, l.secs] for l in parse_lyrics(strip_bracket_notes(src)).lines]
        assert got == exp, f"case {i}: {got} != {exp}"


def test_srt() -> None:
    srt = "\ufeff1\n00:00:01,500 --> 00:00:03,000\n一行目\n二段目\n\n2\n00:00:04,000 --> 00:00:05,000\n<i>次</i>\n"
    assert srt_to_lrc(srt) == "[00:01.500]一行目/二段目\n[00:04.000]次"
    p = read_lyrics(srt)  # 自動判定で SRT として読む
    assert [(l.text, l.lrc) for l in p.lines] == [("一行目二段目", 1.5), ("次", 4.0)]


def test_index_and_sung() -> None:
    p = read_lyrics("[Verse]\nあ\n[間奏]\nい\n")
    assert [(l.index, l.text, l.interlude) for l in p.lines] == [(0, "あ", False), (1, "", True), (2, "い", False)]
    assert [l.index for l in p.sung] == [0, 2]


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print(f"OK  {name}")
