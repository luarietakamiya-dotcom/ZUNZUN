"""タスクトレイに常駐して、ローカルサーバーを動かす (ダブルクリックで起動する用)。

  pythonw -m lyricsync tray      (コマンドの画面を出さずに起動)
  python -m lyricsync shortcut   (デスクトップとスタートメニューにショートカットを作る)

アイコンの色で状態がわかる: 青 = 待機中 / オレンジ = 処理中 / 灰 = 起動中。
マウスを乗せると進み具合、右クリックで状態・説明 (/docs)・終了のメニュー。
"""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

from . import __version__

HOME = Path(os.environ.get("LYRICSYNC_HOME", Path.home() / ".lyricsync"))
ICON_FILE = HOME / "lyricsync.ico"
LOG_FILE = HOME / "tray.log"
COLORS = {"starting": (140, 140, 150), "idle": (52, 120, 246), "busy": (245, 140, 30)}


def _icon_image(state: str, size: int = 64):
    """丸に音符のアイコン (Pillow で描く。画像ファイルを同梱しなくて済むように)。"""
    from PIL import Image, ImageDraw

    s = size / 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((2 * s, 2 * s, 62 * s, 62 * s), fill=COLORS[state] + (255,))
    white = (255, 255, 255, 255)
    d.ellipse((14 * s, 38 * s, 28 * s, 50 * s), fill=white)  # 音符の玉 (左)
    d.ellipse((36 * s, 34 * s, 50 * s, 46 * s), fill=white)  # 音符の玉 (右)
    d.rectangle((25 * s, 16 * s, 28 * s, 44 * s), fill=white)  # 棒 (左)
    d.rectangle((47 * s, 12 * s, 50 * s, 40 * s), fill=white)  # 棒 (右)
    d.polygon([(25 * s, 16 * s), (50 * s, 12 * s), (50 * s, 19 * s), (25 * s, 23 * s)], fill=white)  # 連桁
    return img


def _already_running(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1.5) as r:
            return r.status == 200
    except Exception:
        return False


def _message(text: str, title: str = "LyricSync") -> None:
    if os.name == "nt":
        import ctypes

        ctypes.windll.user32.MessageBoxW(None, text, title, 0x40)
    else:
        print(text)


def run_tray(port: int = 8765, model: str = "large-v3", device: str = "auto") -> None:
    HOME.mkdir(parents=True, exist_ok=True)
    if sys.stdout is None or sys.stderr is None:  # pythonw (画面なし) で起動したときは、ログをファイルへ
        log = open(LOG_FILE, "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    if _already_running(port):
        _message(f"LyricSync はもう起動しています (http://127.0.0.1:{port})。\nタスクトレイのアイコンを確かめてください。")
        return

    import pystray

    from .audio import CACHE_DIR
    from .server import start_in_thread

    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] tray 起動 (port {port})", flush=True)
    state = {"text": "起動中…", "kind": "starting"}
    server, runner = start_in_thread(port, model, device)

    def status_text(_item=None) -> str:
        return state["text"]

    def open_docs(_icon=None, _item=None) -> None:
        webbrowser.open(f"http://127.0.0.1:{port}/docs")

    def open_cache(_icon=None, _item=None) -> None:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(CACHE_DIR)  # noqa: S606

    def quit_(icon, _item=None) -> None:
        server.should_exit = True
        icon.stop()

    icon = pystray.Icon(
        "LyricSync", _icon_image("starting"), "LyricSync: 起動中…",
        menu=pystray.Menu(
            pystray.MenuItem(f"LyricSync {__version__}", None, enabled=False),
            pystray.MenuItem(status_text, None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("説明を開く (/docs)", open_docs),
            pystray.MenuItem("キャッシュのフォルダを開く", open_cache),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("終了", quit_),
        ))

    def watch() -> None:
        """1 秒ごとに状態を見て、アイコンの色とマウスを乗せたときの表示を変える。"""
        last = None
        announced = False
        while not server.should_exit:
            if not server.started:
                kind, text = "starting", "起動中…"
            else:
                queued, cur = runner.busy()
                if cur:
                    kind = "busy"
                    text = f"処理中 {int(cur['progress'] * 100)}% {cur['message']}"
                    if queued:
                        text += f" (ほか {queued} 件待ち)"
                else:
                    kind = "idle"
                    loaded = "モデル読み込み済み" if runner.aligner._model is not None else "最初の曲はモデルの読み込みあり"
                    text = f"待機中 ({loaded})"
            if (kind, text) != last:
                state.update(kind=kind, text=text)
                icon.icon = _icon_image(kind)
                icon.title = f"LyricSync: {text}"[:127]  # Windows の表示は 128 文字まで
                icon.update_menu()
                last = (kind, text)
            if kind != "starting" and not announced:
                # Windows 11 では新しいアイコンは最初「^」の中にしまわれて見えないので、起動したことを通知で知らせる
                announced = True
                try:
                    icon.notify("タスクバーの「^」の中にアイコンがあります。ドラッグしてタスクバーに出しておけます。",
                                "LyricSync を起動しました")
                except Exception as e:
                    print(f"通知を出せませんでした: {e}", flush=True)
            time.sleep(1.0)

    threading.Thread(target=watch, daemon=True).start()
    icon.run()
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] tray 終了", flush=True)


def make_shortcuts(startup: bool = False) -> list[Path]:
    """デスクトップとスタートメニューに「LyricSync」のショートカットを作る。startup=True ならログオン時の自動起動も。"""
    if os.name != "nt":
        raise RuntimeError("ショートカットを作れるのは Windows だけです")
    HOME.mkdir(parents=True, exist_ok=True)
    _icon_image("idle", 256).save(ICON_FILE, sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (256, 256)])
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    if not pythonw.exists():
        pythonw = Path(sys.executable)
    appdata = Path(os.environ["APPDATA"])
    targets = [Path(os.environ["USERPROFILE"]) / "Desktop", appdata / "Microsoft/Windows/Start Menu/Programs"]
    if startup:
        targets.append(appdata / "Microsoft/Windows/Start Menu/Programs/Startup")
    made = []
    for folder in targets:
        lnk = folder / "LyricSync.lnk"
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LS_LNK);"
              "$s.TargetPath=$env:LS_TARGET;$s.Arguments='-m lyricsync tray';"
              "$s.WorkingDirectory=$env:LS_HOME;$s.IconLocation=$env:LS_ICON;"
              "$s.Description='LyricSync (歌詞の自動タイミング合わせ) を起動してタスクトレイに常駐';$s.Save()")
        env = dict(os.environ, LS_LNK=str(lnk), LS_TARGET=str(pythonw), LS_HOME=str(HOME), LS_ICON=str(ICON_FILE))
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, env=env,
                       creationflags=subprocess.CREATE_NO_WINDOW)
        made.append(lnk)
    return made
