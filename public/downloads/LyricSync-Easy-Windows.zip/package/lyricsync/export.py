"""結果の書き出し。どのホストツールでも読めるよう、よく使われる形式をひととおり出す。"""

from __future__ import annotations

import json

from .aligner import AlignResult

FORMATS = ("lrc", "elrc", "srt", "json", "zunzun")


def _lrc_time(t: float) -> str:
    t = max(0.0, t)
    return f"{int(t // 60):02d}:{t % 60:05.2f}"


def _srt_time(t: float) -> str:
    ms = int(round(max(0.0, t) * 1000))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def to_lrc(res: AlignResult) -> str:
    """行ごとの LRC。間奏は [間奏] 行として残す (ZUNZUN / JIZURA で読み直しても行番号が変わらない)。"""
    return "\n".join(f"[{_lrc_time(l.start)}]{l.text if l.status != 'interlude' else '[間奏]'}" for l in res.lines)


def to_elrc(res: AlignResult) -> str:
    """単語ごとの時刻つき LRC (Enhanced LRC / A2 拡張)。カラオケ表示用。"""
    rows = []
    for l in res.lines:
        if l.status == "interlude":
            rows.append(f"[{_lrc_time(l.start)}][間奏]")
        elif l.words:
            rows.append(f"[{_lrc_time(l.start)}]" + "".join(f"<{_lrc_time(w.start)}>{w.text}" for w in l.words)
                        + f"<{_lrc_time(l.end)}>")
        else:
            rows.append(f"[{_lrc_time(l.start)}]{l.text}")
    return "\n".join(rows)


def to_srt(res: AlignResult) -> str:
    sung = [l for l in res.lines if l.status != "interlude"]
    return "\n\n".join(f"{i}\n{_srt_time(l.start)} --> {_srt_time(l.end)}\n{l.text}"
                       for i, l in enumerate(sung, 1)) + "\n"


def to_zunzun_timing(res: AlignResult) -> dict:
    """ZUNZUN の Project JSON の lyrics.timing に入れる形 (JIZURA の timing.lineTimes と互換)。"""
    times = {str(l.index): l.start for l in res.lines if l.status != "interlude"}
    ends = {str(l.index): l.end for l in res.lines if l.status != "interlude"}
    return {"lineTimes": times, "lineEnds": ends, "snap": True, "snapWindowMs": 150}


def render(res: AlignResult, fmt: str) -> str:
    if fmt == "lrc":
        return to_lrc(res)
    if fmt == "elrc":
        return to_elrc(res)
    if fmt == "srt":
        return to_srt(res)
    if fmt == "json":
        return json.dumps(res.to_dict(), ensure_ascii=False, indent=2)
    if fmt == "zunzun":
        return json.dumps(to_zunzun_timing(res), ensure_ascii=False, indent=2)
    raise ValueError(f"知らない形式です: {fmt} (使えるのは {', '.join(FORMATS)})")


EXT = {"lrc": ".lrc", "elrc": ".word.lrc", "srt": ".srt", "json": ".lyricsync.json", "zunzun": ".zunzun-timing.json"}
