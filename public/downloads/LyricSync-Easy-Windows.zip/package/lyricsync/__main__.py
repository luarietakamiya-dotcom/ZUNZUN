"""コマンドの入口。

  python -m lyricsync align 曲.wav 歌詞.txt [-o 出力フォルダ] [--formats lrc,srt,...]
  python -m lyricsync serve [--port 8765]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main(argv=None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(prog="lyricsync", description="歌詞の自動タイミング合わせ")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("align", help="曲と歌詞から、タイミングつきの歌詞を作る")
    a.add_argument("audio", help="曲のファイル (wav/mp3/flac/m4a/mp4 など ffmpeg が読めるもの)")
    a.add_argument("lyrics", help="歌詞のファイル (テキスト / LRC / SRT)")
    a.add_argument("-o", "--out", help="出力フォルダ (省略すると曲と同じ場所)")
    a.add_argument("--formats", default="lrc,elrc,srt,json,zunzun", help="出力形式 (カンマ区切り)")
    a.add_argument("--vocals", help="ボーカルのステムがあれば指定 (分離を飛ばして精度も上がる)")
    a.add_argument("--language", default="ja", help="言語コード。auto で自動判定")
    a.add_argument("--model", default="large-v3", help="Whisper モデル (large-v3 / medium / small)")
    a.add_argument("--no-separate", action="store_true", help="ボーカル分離をしない (伴奏の無い音源用)")
    a.add_argument("--mms", action="store_true",
                   help="合わせにくい行に MMS も使う (英語の掛け声などが合いやすい。モデルは CC-BY-NC 4.0 = 非商用)")
    a.add_argument("--device", default="auto")

    for name, help_ in (("serve", "ほかのツールから使うためのローカル HTTP サーバーを起動"),
                        ("tray", "サーバーを起動してタスクトレイに常駐 (ダブルクリック起動用)")):
        s = sub.add_parser(name, help=help_)
        s.add_argument("--port", type=int, default=8765)
        s.add_argument("--model", default="large-v3")
        s.add_argument("--device", default="auto")

    sc = sub.add_parser("shortcut", help="デスクトップとスタートメニューに起動用のショートカットを作る")
    sc.add_argument("--startup", action="store_true", help="Windows にログオンしたとき自動で起動する")

    args = p.parse_args(argv)

    if args.cmd == "serve":
        from .server import run

        run(port=args.port, model=args.model, device=args.device)
        return 0
    if args.cmd == "tray":
        from .tray import run_tray

        run_tray(port=args.port, model=args.model, device=args.device)
        return 0
    if args.cmd == "shortcut":
        from .tray import make_shortcuts

        for lnk in make_shortcuts(startup=args.startup):
            print(f"作りました: {lnk}")
        return 0

    from .aligner import Aligner
    from .export import EXT, render

    audio = Path(args.audio)
    text = Path(args.lyrics).read_text(encoding="utf-8-sig")
    res = Aligner(args.model, args.device).align(
        audio, text, language=None if args.language == "auto" else args.language,
        separate=not args.no_separate, vocals_path=args.vocals, mms=args.mms)
    out = Path(args.out) if args.out else audio.parent
    out.mkdir(parents=True, exist_ok=True)
    for fmt in [f.strip() for f in args.formats.split(",") if f.strip()]:
        dst = out / (audio.stem + EXT[fmt])
        dst.write_text(render(res, fmt), encoding="utf-8")
        print(f"書き出し: {dst}")
    if res.review:
        print(f"要確認の行 (0 始まり): {res.review}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
