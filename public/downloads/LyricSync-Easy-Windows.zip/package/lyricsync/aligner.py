"""歌詞の自動タイミング合わせの本体。

流れ:
  1. 歌詞を ZUNZUN と同じ規則で行に分ける (lyrics.py)
  2. Demucs でボーカルだけを取り出す (伴奏に引っぱられないように)
  3. Whisper (stable-ts) で歌詞の文字と声を強制アライメントする (文字起こしではなく、渡した歌詞に合わせる)
  4. 単語の時刻を行に割り当て、ボーカルの音量を見て行の頭と終わりを直す (_refine_line)
  5. 自信の低い行を、前後のうまく合った行にはさまれた範囲の音だけで合わせ直す (_heal)
  6. それでも合わない行 (単語が取れない・順序が逆転・短すぎる) は前後から推定し、「要確認」にする
テスト結果は README.md に書いた。歌い出しへの吸着・stable-ts の refine・頭に無音を足す も試したが、
精度が上がらない (吸着と無音はむしろ悪化する) ので入れていない。
すべてローカルで動き、音源や歌詞を外部へ送らない (モデルの初回ダウンロードだけネットを使う)。
"""

from __future__ import annotations

import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from . import audio as A
from .lyrics import ParsedLyrics, read_lyrics

SR = 16000
HOP = 0.01  # 音量の包絡の間隔 (秒)
WIN_CENTER = 0.015  # 包絡の窓 (30ms) の中央
VOICE_DB = 15.0  # 近くのいちばん大きい声からこれ以上小さい所は「声なし」(伴奏の漏れ) とみなす


class Cancelled(BaseException):
    """align() の途中で取り消された。

    BaseException にしてあるのは、処理の中の「失敗しても続ける」ための except Exception に
    飲み込まれずに、確実に外まで届くようにするため。
    """


@dataclass
class Word:
    text: str
    start: float
    end: float
    prob: float


@dataclass
class AlignedLine:
    index: int
    text: str
    start: float
    end: float
    confidence: float
    status: str
    """'ok' | 'low' (自信が低い) | 'estimated' (アライメントに失敗し前後から推定) | 'interlude'"""
    words: list[Word] = field(default_factory=list)


@dataclass
class AlignResult:
    lines: list[AlignedLine]
    duration: float
    language: str
    model: str
    elapsed: float
    settings: dict

    @property
    def review(self) -> list[int]:
        return [l.index for l in self.lines if l.status in ("low", "estimated")]

    def to_dict(self) -> dict:
        d = asdict(self)
        d["review"] = self.review
        return d


def _log(msg: str) -> None:
    print(msg, flush=True)


class Aligner:
    """モデルを一度読み込んで使い回す。サーバーやホストアプリは 1 つ作って保持する。"""

    def __init__(self, model: str = "large-v3", device: str = "auto", demucs_model: str = "htdemucs",
                 log=_log):
        import torch

        self.device = ("cuda" if torch.cuda.is_available() else "cpu") if device == "auto" else device
        self.model_name = model
        self.demucs_model = demucs_model
        self.log = log
        self._model = None
        self._mms = None
        self._check = lambda: None
        self._use_mms = False

    @property
    def model(self):
        if self._model is None:
            import stable_whisper

            self.log(f"Whisper モデルを読み込み中 ({self.model_name}, {self.device}) ...")
            self._model = stable_whisper.load_model(self.model_name, device=self.device)
        return self._model

    # ------------------------------------------------------------------ 公開 API

    def align(self, audio_path: str | Path, lyrics: str, source: str = "auto", language: str | None = "ja",
              separate: bool = True, vocals_path: str | Path | None = None, progress=None,
              cancel=None, mms: bool = False) -> AlignResult:
        """audio_path の曲に lyrics (テキスト / LRC / SRT) を合わせる。

        vocals_path: ボーカルのステムがすでにあるならそれを渡す (分離を飛ばす)。
        separate: False にすると分離せずにそのまま合わせる (伴奏が無い音源用。伴奏があると大きくずれる)。
        progress: (割合 0..1, メッセージ) を受け取る関数。
        mms: 合わせにくい行の多数決に MMS (torchaudio の MMS_FA) も使う。MMS のモデルは CC-BY-NC 4.0 (非商用) なので、
            既定では使わない。使うと英語の掛け声やシャウトの位置が合いやすくなる。
        cancel: 取り消されたら True を返す関数。処理の区切りごとに見て、True なら Cancelled を投げて止める
            (Whisper の呼び出しの途中でも、stable-ts の progress_callback で確かめる)。
        """
        t0 = time.time()

        def check() -> None:
            if cancel is not None and cancel():
                raise Cancelled()

        self._check = check
        self._use_mms = mms
        report = progress or (lambda p, m: self.log(f"[{int(p * 100):3d}%] {m}"))

        def step(p: float, m: str) -> None:
            check()
            report(p, m)

        parsed = read_lyrics(lyrics, source)
        sung = parsed.sung
        if not sung:
            raise ValueError("歌詞の行がありません。")

        step(0.05, "ボーカルを準備中")
        if vocals_path:
            vpath = Path(vocals_path)
        elif separate:
            vpath = A.separate_vocals(audio_path, self.demucs_model, self.device, log=self.log,
                                      callback=lambda _: check())
            self._free_gpu()
        else:
            vpath = Path(audio_path)
        y = A.load_audio(vpath, SR)[0]
        duration = len(y) / SR

        step(0.35, "歌詞と声を合わせています")
        words_by_line = self._force_align(y, [l.text for l in sung], language)

        step(0.85, "行の時刻を整えています")
        env = A.envelope_db(y, SR, HOP)
        floor = _noise_floor(env)
        prev_end, doubtful = 0.0, []
        for ws in words_by_line:
            ws[:] = [w for w in ws if w.end > w.start]
            doubtful.append(_doubtful(ws, env, floor))
            prev_end = _refine_line(ws, env, floor, prev_end)
        lines = self._build_lines(parsed, sung, words_by_line, duration, doubtful)
        _mark_silent(lines, env, floor)
        if any(l.status in ("low", "estimated") for l in lines):
            step(0.9, "合わなかった行をその周りだけで合わせ直しています")
            mix = (lambda: A.load_audio(audio_path, SR)[0]) if (separate or vocals_path) else (lambda: y)
            # 曲全体での強制アライメントの開始 (自信が低くても、聞き取りとの照合の目安の 1 つにする)
            first = {l.index: l.start for l in lines if l.status in ("ok", "low") and l.words}
            self._heal(lines, y, env, floor, language, duration, mix, first)
        self._fill_interludes(lines, duration)

        res = AlignResult(lines, duration, language or "auto", self.model_name, time.time() - t0,
                          {"separate": separate and not vocals_path, "vocals_given": bool(vocals_path),
                           "demucs_model": self.demucs_model, "mms": mms})
        step(1.0, f"完了 ({res.elapsed:.1f} 秒, 要確認 {len(res.review)} 行)")
        return res

    # ------------------------------------------------------------------ 内部

    def _on_progress(self, *_args) -> None:
        """stable-ts が呼び出しの途中で呼ぶ。ここで取り消しを確かめれば、長い呼び出しの途中でも止まれる。"""
        self._check()

    def _free_gpu(self) -> None:
        try:
            import torch

            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass

    def _force_align(self, y: np.ndarray, texts: list[str], language: str | None) -> list[list[Word]]:
        """強制アライメント。VAD ありで合わせ、崩れていたら VAD なしでやり直して、崩れの少ない方を使う。

        vad=True (Silero VAD) で無音を判定させると、イントロの間に歌詞を置いてしまう失敗がなくなる
        (人が付けた LRC との比較で、1 秒以内に入る行が 72% → 93%)。ただ、まれに途中から全部の行が
        同じ時刻に積み重なって崩れることがある (THREE COUNT の mp3 の 1 つで、56 行中 21 行が 15.7 秒に重なった。
        同じ音の別の mp3 や wav では起きない)。その音でも VAD なしなら合う。
        頭に無音を足すと冒頭の行が良くなるかも試したが、本物の曲では逆に悪くなったので足さない。
        """
        wbl = self._align_once(y, texts, language, vad=True)
        if _collapse(wbl) > 0.1 * len(texts):
            self.log("アライメントが崩れたので、VAD なしでやり直します")
            alt = self._align_once(y, texts, language, vad=False)
            if _collapse(alt) < _collapse(wbl):
                return alt
        return wbl

    def _align_once(self, y: np.ndarray, texts: list[str], language: str | None, vad: bool) -> list[list[Word]]:
        result = self.model.align(y, "\n".join(texts), language=language, original_split=True,
                                  suppress_silence=True, vad=vad, regroup=False, verbose=None,
                                  progress_callback=self._on_progress)
        words = [w for seg in result.segments for w in (seg.words or [])]
        return _assign_words(words, texts)

    def _build_lines(self, parsed: ParsedLyrics, sung, words_by_line, duration, doubtful) -> list[AlignedLine]:
        out: dict[int, AlignedLine] = {}
        for l, ws, dbt in zip(sung, words_by_line, doubtful):
            ws = [w for w in ws if w.end > w.start]
            if ws:
                conf = float(np.mean([w.prob for w in ws]))
                out[l.index] = AlignedLine(l.index, l.text, ws[0].start, max(w.end for w in ws), conf,
                                           "ok" if conf >= 0.35 and not dbt else "low", ws)
            else:
                out[l.index] = AlignedLine(l.index, l.text, -1, -1, 0.0, "estimated", [])
        _repair(list(out.values()), duration)
        lines = []
        for l in parsed.lines:
            lines.append(out.get(l.index) or AlignedLine(l.index, "", -1, -1, 1.0, "interlude"))
        return lines

    def _heal(self, lines: list[AlignedLine], y: np.ndarray, env: np.ndarray, floor: float,
              language: str | None, duration: float, mix, first: dict[int, float]) -> None:
        """自信の低い行・推定した行を、前後のうまく合った行にはさまれた範囲の音だけで合わせ直す。

        曲全体で合わせると、歌詞から 1 行抜けているだけで後ろの行がまとめて引っぱられることがある。
        範囲を狭めれば取り違えが起きにくい。それでも合わない区間は、聞き取りとの照合で置く (_match_transcript)。
        どちらもだめなら元のまま (要確認) にしておく。
        """
        sung = [l for l in lines if l.status != "interlude"]
        for run, t0, t1 in _bad_runs(sung, duration):
            self._check()
            if t1 - t0 >= 0.5:
                seg = y[int(t0 * SR):int(t1 * SR)]
                try:
                    wbl = self._force_align(seg, [l.text for l in run], language)
                except Exception:
                    wbl = []
                lo = t0
                for l, ws in zip(run, wbl):
                    ws = [w for w in ws if w.end > w.start]
                    for w in ws:
                        w.start, w.end = round(w.start + t0, 3), round(w.end + t0, 3)
                    if not ws:
                        continue
                    dbt = _doubtful(ws, env, floor)
                    _refine_line(ws, env, floor, lo)
                    conf = float(np.mean([w.prob for w in ws]))
                    s, e = ws[0].start, ws[-1].end
                    chars = max(1, len(_norm(l.text)))
                    if (conf >= 0.35 and s >= lo - 0.05 and e <= t1 + 0.05
                            and 0.04 * chars <= e - s <= 2.5 * chars + 4 and _voiced(env, floor, s, e)):
                        l.start, l.end, l.words, l.confidence = s, e, ws, conf
                        l.status = "ok" if conf >= 0.5 and not dbt else "low"
                        lo = e
        mix_y = None
        for run, t0, t1 in _bad_runs(sung, duration):
            if t1 - t0 < 0.5:
                continue
            if mix_y is None:
                mix_y = mix()
            try:
                self._match_transcript(run, t0, t1, mix_y, y, env, floor, language, first)
            except Exception as e:
                # 合わせ直しは精度を上げるための最後の手段。ここで失敗しても仕事全体は止めず、
                # この区間は今の位置のまま「要確認」で返す (取り消しの Cancelled は BaseException なので通り抜ける)
                self.log(f"{t0:.1f}〜{t1:.1f} 秒の合わせ直しに失敗しました (要確認のまま): {type(e).__name__}: {e}")
        _repair(sung, duration)

    def _match_transcript(self, run: list[AlignedLine], t0: float, t1: float, mix: np.ndarray, voc: np.ndarray,
                          env: np.ndarray, floor: float, language: str | None, first: dict[int, float]) -> None:
        """強制アライメントで合わなかった区間を、いくつかの方法の「多数決」で置く。

        英語の掛け声やシャウトは、歌詞を当てはめる方式では合わないことがある (THREE COUNT が
        「Trick & Roll」に聞こえる、など)。そこでこの区間を 8 通りに聞き取る
        (元の音 / ボーカル × 歌詞の言語 / 英語 × 歌詞をヒントに渡す / 渡さない)。
        それぞれ、歌詞と聞き取りをローマ字にして、順番を保ったまま読みのいちばん近い組み合わせを選ぶ (動的計画法)。
        ボーカルが鳴っていない所の聞き取り (「ご視聴ありがとうございました」のような幻聴) は捨てる。

        行の終わり: 聞き取りの単語の「終わり」は聞き取り方を変えても揃うので、0.6 秒以内にいちばん多く集まった所の中央値。
        行の始まり: 「始まり」は方法ごとに癖がある (スペクトログラムを見て確かめた):
          W  聞き取りで終わりが揃ったものの中でいちばん遅い始まり (Whisper は前の伸ばしまで引き伸ばし、早すぎがち)
          P  歌詞をヒントにした聞き取りの、最初の単語の始まりの中央値
          M  MMS (CTC の強制アライメント、関係ない音は読み飛ばす) をボーカルにかけた始まり
             (シャウトに強いが、ハモリが重なると頭の言葉を読み飛ばして遅すぎがち)
          F  曲全体での最初の強制アライメントの始まり (自信が低いと出ていても位置は合っていることがある)
        どれか 2 つが 0.4 秒以内で一致したらその平均を使い、終わりも 4 つ以上の聞き取りで揃っていれば「ok」。
        一致しなければ M (無ければ W) を使い「要確認」にする。
        """
        prompt = " ".join(l.text for l in run)
        romans = [_roman(l.text) for l in run]
        cands: list[list[tuple[float, float, float, bool]]] = [[] for _ in run]
        for src in (mix, voc):
            seg = src[int(t0 * SR):int(t1 * SR)]
            for lang in dict.fromkeys([language, "en"]):
                for hint in (prompt, None):
                    self._check()
                    try:
                        r = self.model.transcribe(seg, language=lang, vad=False, word_timestamps=True,
                                                  regroup=False, verbose=None, initial_prompt=hint,
                                                  temperature=0.0,
                                                  progress_callback=self._on_progress)
                    except Exception:
                        continue
                    words = [Word(w.word.strip(), w.start + t0, w.end + t0, float(w.probability or 0))
                             for s in r.segments if _voiced(env, floor, s.start + t0, s.end + t0)
                             for w in (s.words or []) if _roman(w.word)]
                    if not words:
                        continue
                    for i, span in enumerate(_match_spans(romans, [_roman(w.text) for w in words])):
                        if span:
                            j, k, sim = span
                            cands[i].append((words[j].start, words[k - 1].end, sim, hint is not None))
        self._check()
        # MMS のモデルは CC-BY-NC 4.0 (非商用)。頼まれたときだけ使う
        mms = (self._mms_align(voc[int(t0 * SR):int(t1 * SR)], romans) if self._use_mms
               else [None] * len(romans))
        lo = t0
        for l, cs, m in zip(run, cands, mms):
            if not cs:
                continue
            # 終わりは「0.6 秒以内にいちばん多くの聞き取りが集まっている所」。全体の中央値にすると、
            # 候補が 2 つの塊に分かれたとき (偶数個) に中央値がどちらからも離れ、そばに候補が 1 つも無くなる
            agree = max(([c for c in cs if abs(c[1] - x[1]) <= 0.6] for x in cs), key=len)
            e = float(np.median([c[1] for c in agree]))
            # W と P はどちらも Whisper なので同じように外れる。一致を見るのは仕組みの違うもの (Whisper / MMS / 最初の強制アライメント) の間だけ
            est = {"W": max(c[0] for c in agree)}
            m_end = None
            if m and abs(m[1] + t0 - e) <= 0.5:
                est["M"], m_end = m[0] + t0, m[1] + t0
            if l.index in first:
                est["F"] = first[l.index]
            if os.environ.get("LYRICSYNC_DEBUG"):
                self.log(f"[debug] {l.index} {l.text} e={e:.2f} lo={lo:.2f} est={ {k: round(v, 2) for k, v in est.items()} }")
            # MMS の始まりは MMS 自身の終わりと組みで使う (Whisper の終わりが早すぎることがある)
            hi = {k: (max(e, m_end) if k == "M" else e) - 0.15 for k in est}
            est = {k: v for k, v in est.items() if lo - 0.05 <= v <= hi[k]}
            pairs = sorted((abs(a - b), (a + b) / 2) for ka, a in est.items() for kb, b in est.items() if ka < kb)
            if pairs and pairs[0][0] <= 0.4:
                s, agreed = pairs[0][1], True
            elif est:
                # 一致しなければ、サビ頭などで位置が合っていることの多い順に
                key = next(k for k in ("F", "M", "W") if k in est)
                s, agreed = est[key], False
                if key == "M":
                    e = max(e, m_end)
            else:
                continue
            s, e = _trim_to_voice(env, floor, max(s, lo), e)
            if e <= lo or e - s < 0.05:
                continue
            sim = float(np.mean([c[2] for c in agree]))
            l.start, l.end, l.words, l.confidence = round(s, 3), round(e, 3), [], round(sim, 3)
            l.status = "ok" if agreed and sim >= 0.5 else "low"
            lo = l.end

    def _mms_align(self, y: np.ndarray, romans: list[str]) -> list[tuple[float, float] | None]:
        """MMS (torchaudio の多言語 CTC 強制アライメント) で、行ごとの (始まり, 終わり) を出す。

        行と行の間と両端に「関係ない音」を読み飛ばす記号 (*) を入れるので、歌詞に無い伸ばしやコーラスに
        引っぱられにくい。歌詞はローマ字で渡す。使えないときは全部 None。
        """
        try:
            import torch
            import torchaudio
            import torchaudio.functional as F

            if self._mms is None:
                bundle = torchaudio.pipelines.MMS_FA
                self._mms = (bundle.get_model(with_star=True).to(self.device).eval(), bundle.get_dict(star="*"))
            model, dic = self._mms
            wav = torch.from_numpy(np.ascontiguousarray(y, dtype=np.float32))[None].to(self.device)
            with torch.inference_mode():
                em, _ = model(wav)
            toks, owner = [dic["*"]], [-1]
            for i, r in enumerate(romans):
                for c in r:
                    if c in dic:
                        toks.append(dic[c])
                        owner.append(i)
                toks.append(dic["*"])
                owner.append(-1)
            ali, scores = F.forced_align(em, torch.tensor([toks], dtype=torch.int32, device=self.device), blank=0)
            spans = F.merge_tokens(ali[0].cpu(), scores[0].exp().cpu())
        except Exception as e:
            self.log(f"MMS のアライメントは使えませんでした: {e}")
            return [None] * len(romans)
        ratio = wav.shape[1] / em.shape[1] / SR
        out: list[list[float] | None] = [None] * len(romans)
        ti = 0
        for sp in spans:  # merge_tokens は blank を除いたトークンを、渡した順に返す
            while ti < len(toks) and toks[ti] != sp.token:
                ti += 1
            if ti >= len(toks):
                break
            o = owner[ti]
            if o >= 0:
                s, e = sp.start * ratio, sp.end * ratio
                if out[o] is None:
                    out[o] = [s, e]
                out[o][1] = e
            ti += 1
        return [tuple(x) if x else None for x in out]

    def _fill_interludes(self, lines: list[AlignedLine], duration: float) -> None:
        for i, l in enumerate(lines):
            if l.status != "interlude":
                continue
            prev = next((x.end for x in reversed(lines[:i]) if x.status != "interlude"), 0.0)
            nxt = next((x.start for x in lines[i + 1:] if x.status != "interlude"), duration)
            l.start, l.end = round(prev, 3), round(max(prev, nxt), 3)


def _norm(s: str) -> str:
    return "".join(s.split())


def _collapse(wbl: list[list[Word]]) -> int:
    """強制アライメントの崩れの大きさ: 単語の取れなかった行と、ほかの行と同じ時刻 (0.1 秒単位) に重なった行の数。"""
    starts = [round(ws[0].start, 1) for ws in wbl if ws]
    return (len(wbl) - len(starts)) + (len(starts) - len(set(starts)))


def _bad_runs(sung: list[AlignedLine], duration: float) -> list[tuple[list[AlignedLine], float, float]]:
    """合わなかった行のひと続きと、それをはさむうまく合った行の間の時間 (t0, t1)。"""
    bad = lambda l: l.status in ("low", "estimated")  # noqa: E731
    runs, i = [], 0
    while i < len(sung):
        if not bad(sung[i]):
            i += 1
            continue
        j = i
        while j < len(sung) and bad(sung[j]):
            j += 1
        runs.append((sung[i:j], sung[i - 1].end if i > 0 else 0.0, sung[j].start if j < len(sung) else duration))
        i = j
    return runs


def _voiced(env: np.ndarray, floor: float, t0: float, t1: float, min_frac: float = 0.2) -> bool:
    """[t0, t1] でボーカルが (弱くても) 鳴っている割合が min_frac 以上か。"""
    if not len(env):
        return True
    a, b = _frame(t0, env), _frame(t1, env)
    return b >= a and float((env[a:b + 1] >= floor + 12).mean()) >= min_frac


def _trim_to_voice(env: np.ndarray, floor: float, t0: float, t1: float) -> tuple[float, float]:
    """[t0, t1] の両端の無音を削って、ボーカルが 50ms 以上続けて鳴っている所だけにする。無ければそのまま。"""
    if not len(env):
        return t0, t1
    a, b = _frame(t0, env), _frame(t1, env)
    v = env[a:b + 1] >= floor + 12
    run = np.convolve(v.astype(int), np.ones(5, int), "valid") == 5
    idx = np.nonzero(run)[0]
    if not len(idx):
        return t0, t1
    return (a + idx[0]) * HOP + WIN_CENTER - 0.01, min(t1, (a + idx[-1] + 5) * HOP + 2 * WIN_CENTER)


def _mark_silent(lines: list[AlignedLine], env: np.ndarray, floor: float) -> None:
    """ボーカルがほとんど鳴っていない所に置かれた行は、Whisper の自信が高くても「要確認」にする。"""
    for l in lines:
        if l.status == "ok" and not _voiced(env, floor, l.start, l.end):
            l.status = "low"


_kakasi = None
_DIGITS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]


def _roman(text: str) -> str:
    """読みをローマ字 (小文字の a-z だけ) にする。数字は英語の読みにする。"""
    global _kakasi
    if _kakasi is None:
        import pykakasi

        _kakasi = pykakasi.kakasi()
    s = "".join(x["hepburn"] for x in _kakasi.convert(text)).lower()
    s = "".join(_DIGITS[int(c)] if c.isdigit() else c for c in s)
    return "".join(c for c in s if "a" <= c <= "z")


def _match_spans(lines: list[str], words: list[str], max_span: int = 16) -> list[tuple[int, int, float] | None]:
    """歌詞の行 (ローマ字) と聞き取りの単語 (ローマ字) を、順番を保って対応付ける。

    各行に連続した単語の範囲を 1 つ割り当て、読みの近さ (difflib の ratio) の合計がいちばん大きくなる組み合わせを
    動的計画法で選ぶ。対応しない単語 (「Yeah!」のような歌詞に無い掛け声) は小さな減点で飛ばせる。
    戻り値は行ごとの (単語の開始, 終了 (含まない), 近さ)。近さが低すぎる行は None。
    """
    import difflib

    L, W = len(lines), len(words)
    NEG = float("-inf")
    dp = [[NEG] * (W + 1) for _ in range(L + 1)]
    back: list[list[tuple | None]] = [[None] * (W + 1) for _ in range(L + 1)]
    dp[0][0] = 0.0
    for i in range(L + 1):
        for j in range(W + 1):
            v = dp[i][j]
            if v == NEG:
                continue
            if j < W and v - 0.1 > dp[i][j + 1]:  # 単語を飛ばす
                dp[i][j + 1], back[i][j + 1] = v - 0.1, ("skip", i, j)
            if i < L:
                if v - 0.3 > dp[i + 1][j]:  # この行は対応なし
                    dp[i + 1][j], back[i + 1][j] = v - 0.3, ("none", i, j)
                for k in range(j + 1, min(W, j + max_span) + 1):
                    sim = difflib.SequenceMatcher(None, lines[i], "".join(words[j:k]), autojunk=False).ratio()
                    if v + sim > dp[i + 1][k]:
                        dp[i + 1][k], back[i + 1][k] = v + sim, ("take", i, j, sim)
    out: list[tuple[int, int, float] | None] = [None] * L
    i, j = L, W
    while (i, j) != (0, 0):
        b = back[i][j]
        if b[0] == "take":
            out[b[1]] = (b[2], j, b[3]) if b[3] >= 0.3 else None
        i, j = b[1], b[2]
    return out


def _assign_words(words, texts: list[str]) -> list[list[Word]]:
    """stable-ts の単語を、歌詞の文字の位置で行に割り当てる。

    単語の文字列をつなぐと歌詞 (空白を除く) に戻るはずなので、先頭から文字の位置を進める。
    表記の揺れで合わない時は、少し先まで探して追いつく。
    """
    owner: list[int] = []
    for li, t in enumerate(texts):
        owner += [li] * len(_norm(t))
    stream = "".join(_norm(t) for t in texts)
    out: list[list[Word]] = [[] for _ in texts]
    pos = 0
    for w in words:
        wt = _norm(w.word)
        if not wt:
            continue
        if stream.startswith(wt, pos):
            at = pos
        else:
            at = stream.find(wt, pos, pos + 40 + len(wt))
            if at < 0:
                at = pos
        if at >= len(stream):
            break
        li = owner[at]
        prob = float(getattr(w, "probability", None) or 0.0)
        out[li].append(Word(w.word.strip(), round(float(w.start), 3), round(float(w.end), 3), round(prob, 3)))
        pos = min(len(stream), at + len(wt))
    return out


def _frame(t: float, env: np.ndarray) -> int:
    return int(min(max(0, round((t - WIN_CENTER) / HOP)), len(env) - 1))


def _span_max(env: np.ndarray, t0: float, t1: float) -> float:
    a, b = _frame(t0, env), _frame(t1, env)
    return float(env[a:b + 1].max()) if b >= a else float(env[a])


QUIET_BEFORE = 10  # 立ち上がりの手前に要る無音のフレーム数 (0.1 秒)
QUIET_AFTER = 15  # 声の終わりの後ろに要る無音のフレーム数 (0.15 秒)


def _onsets(on: np.ndarray, a: int, b: int) -> list[int]:
    """フレーム a..b の中で、0.1 秒以上の無音のあとに声が始まるフレーム。
    一瞬のクリック音・破裂音を拾わないよう、そのあと 50ms 以上声が続くものだけ。"""
    return [k for k in range(max(a, QUIET_BEFORE), min(b, len(on) - 5) + 1)
            if on[k:k + 5].all() and not on[k - QUIET_BEFORE:k].any()]


def _offsets(on: np.ndarray, a: int, b: int) -> list[int]:
    """フレーム a..b の中で、声が終わり 0.15 秒以上の無音が続くフレーム (声の最後のフレーム)。"""
    n = len(on)
    return [k for k in range(max(0, a), min(b, n - QUIET_AFTER - 1) + 1)
            if on[k] and not on[k + 1:k + 1 + QUIET_AFTER].any()]


def _noise_floor(env: np.ndarray) -> float:
    """ボーカルの「無音」(伴奏の漏れ) の音量。

    ほとんど休まず歌う曲では下位の音量も声なので、いちばん大きい声から 30dB 下より上にはしない。
    """
    if not len(env):
        return -120.0
    return float(min(np.percentile(env, 20), np.percentile(env, 95) - 30))


def _doubtful(ws: list[Word], env: np.ndarray, floor: float) -> bool:
    """行の前半に「1 秒を超えるのに Whisper がまったく自信の無い単語」が、声の上にあるか。

    歌詞に無い声 (抜けた行など) の上に置かれたときに出る形だが、本物の歌で弱く長く伸ばした歌い出しも
    同じ形になる。どちらか見分けられないので時刻は動かさず、「要確認」にして周りだけで合わせ直す (_heal)。
    (下が無音なら、行と行の間の無音を飲み込んだだけなので _refine_line で確実に直せる)
    """
    if not len(env):
        return False
    soft = env >= floor + 12
    total, acc = sum(len(_norm(w.text)) for w in ws), 0
    for w in ws:
        if w.end - w.start > 1.0 and w.prob < 0.1:
            a, b = _frame(w.start, env), _frame(w.end, env)
            if b >= a and soft[a:b + 1].mean() >= 0.3:
                return True
        acc += len(_norm(w.text))
        if acc > total / 2:
            break
    return False


def _refine_line(ws: list[Word], env: np.ndarray, floor: float, lo: float) -> float:
    """1 行ぶんの単語の時刻を、ボーカルの音量を見て直す。直した行の終わりを返す。

    はっきりした証拠 (無音 → 声 / 声 → 無音 の切り替わり) があるときだけ動かす。
    本物の歌は行と行の間も声が続く (伸ばし・コーラス・残響) ことが多く、そこでは音量から行の頭は決められないので
    Whisper の時刻をそのまま使う。

      - 行の頭のほうの単語のあとに 0.6 秒以上の無音があるなら、その単語は前の行の声に貼り付いている
        (Whisper の取り違え)。無音の後ろの単語を頭の目印にする。行の終わりも同じ
      - ほぼ無音の中に置かれた長い単語 (行と行の間の無音を飲み込んだもの) も目印にしない
      - 目印の単語の中か、その 0.15 秒手前に声の立ち上がりがあれば、そこを行の開始にする
      - 目印の単語の中で声が終わって無音が続くなら、そこを行の終わりにする
    分離したボーカルには伴奏の漏れが残るので、「声」の閾値はその行のいちばん大きい声から VOICE_DB 下げた所にする。
    """
    if not ws or not len(env):
        return lo
    n = len(ws)
    chars = [max(1, len(_norm(w.text))) for w in ws]
    total = sum(chars)
    peak = max(_span_max(env, w.start, w.end) for w in ws)
    on = env >= max(floor + 12, peak - VOICE_DB)

    soft = env >= floor + 12  # 弱く歌った声も含めた「何か鳴っている」

    def frac(mask: np.ndarray, w: Word) -> float:
        a, b = _frame(w.start, env), _frame(w.end, env)
        return float(mask[a:b + 1].mean()) if b >= a else 1.0

    def silent_word(k: int) -> bool:
        # 長い単語は、弱く伸ばして歌っていることもあるので、弱い声も無いときだけ。
        # 短めの単語は、Whisper 自身も自信が無いときだけ
        dur = ws[k].end - ws[k].start
        return ((dur > 1.0 and frac(soft, ws[k]) < 0.3)
                or (dur > 0.4 and frac(on, ws[k]) < 0.3 and ws[k].prob < 0.5))

    def gap_silent(t0: float, t1: float) -> bool:
        a, b = _frame(t0 + 0.05, env), _frame(t1 - 0.05, env)
        return t1 - t0 >= 0.6 and not on[a:b + 1].any()

    # 行の頭の単語が前の行の声から途切れずに続いていて、そのあと無音になるなら、前の行に貼り付いた取り違え
    # (歌い出しのあとの休符と区別するため、前の行の終わりから頭の単語まで 0.1 秒以上の無音が無いときだけ)
    f0, f1 = _frame(min(lo, ws[0].start) - 0.05, env), _frame(ws[0].start + 0.05, env)
    attached = bool(on[f1]) and not _onsets(on, f0, f1)
    a, acc = 0, 0
    for k in range(n - 1):
        acc += chars[k]
        if acc > total / 2:
            break
        doubtful = attached or all(w.prob < 0.3 for w in ws[:k + 1])
        if silent_word(k) or (doubtful and gap_silent(ws[k].end, ws[k + 1].start)):
            a = k + 1
    b, acc = n - 1, 0
    for k in range(n - 1, 0, -1):
        acc += chars[k]
        if acc > total / 2:
            break
        if silent_word(k):
            b = k - 1
    if a > b:
        a, b = 0, n - 1

    start = ws[a].start
    # 目印より前の単語を飛ばしたときは、その範囲で「声が戻ってきた所」まで遡って探す
    back = max(lo - 0.1, ws[a - 1].start) if a > 0 else max(lo - 0.1, start - 0.15)
    # 頭が無音に置かれているなら、声はもっと後ろから始まっているので 1.2 秒先まで探す。
    # 目印を後ろへ移したときは、目印の単語より後ろには行かない (前の単語の並びが壊れるので)
    fs = _frame(start, env)
    if a > 0:
        ahead = start
    elif not on[fs:fs + 5].all():  # 無音 (か一瞬のクリック音) の上
        ahead = start + 1.2
    else:
        ahead = min(ws[a].end, start + 1.2)
    cands = _onsets(on, _frame(back, env), _frame(ahead + 0.15, env))
    if cands:
        t_of = lambda k: k * HOP + WIN_CENTER  # noqa: E731
        # Whisper は歌い出しの少し後ろを指しがちなので、0.3 秒手前までにあればそれを優先し、無ければ最も近いもの
        just_before = [k for k in cands if start - 0.3 <= t_of(k) <= start]
        k = just_before[-1] if just_before else min(cands, key=lambda k: abs(t_of(k) - start))
        start = t_of(k) - 0.01
    end = ws[b].end
    fa, fb = _frame(max(ws[b].start, end - 1.2), env), _frame(end, env)
    cands = _offsets(on, fa, fb)
    if cands and not on[fb]:
        end = cands[-1] * HOP + 2 * WIN_CENTER
    # 開始が後ろへ動いて追い越した単語は、開始の後ろへ詰め直す (単語の並びを保つ)
    j = a
    while j < b and ws[j].end <= start + 0.03:
        j += 1
    _spread(ws[:j + 1], chars[:j + 1], start, ws[j].end, keep_last_end=True)
    _spread(ws[b:], chars[b:], ws[b].start, max(end, ws[b].start + 0.05), keep_last_end=False)
    return ws[-1].end


def _spread(ws: list[Word], chars: list[int], t0: float, t1: float, keep_last_end: bool) -> None:
    """ws を [t0, t1] に文字数の比で並べ直す。1 つだけなら端だけ合わせる。"""
    if len(ws) == 1:
        ws[0].start, ws[0].end = round(t0, 3), round(max(t1, t0 + 0.02), 3)
        return
    if keep_last_end:
        # 目印の単語 (最後) の長さは保ち、その前の単語だけを詰める
        anchor_start = max(ws[-1].start, t0 + 0.04 * sum(chars[:-1]))
        _spread_even(ws[:-1], chars[:-1], t0, anchor_start)
        ws[-1].start = round(anchor_start, 3)
        ws[-1].end = round(max(ws[-1].end, anchor_start + 0.02), 3)
    else:
        anchor_end = min(ws[0].end, t1 - 0.04 * sum(chars[1:]))
        ws[0].end = round(max(anchor_end, ws[0].start + 0.02), 3)
        _spread_even(ws[1:], chars[1:], ws[0].end, max(t1, ws[0].end + 0.04 * sum(chars[1:])))


def _spread_even(ws: list[Word], chars: list[int], t0: float, t1: float) -> None:
    t, total = t0, sum(chars)
    for w, c in zip(ws, chars):
        span = (t1 - t0) * c / total
        w.start, w.end = round(t, 3), round(t + span, 3)
        t += span


def _repair(lines: list[AlignedLine], duration: float) -> None:
    """順序が逆転した行・短すぎる行・単語の無い行を、前後の信頼できる行から文字数の比で推定し直す。"""
    for i, l in enumerate(lines):
        if l.status == "estimated":
            continue
        chars = max(1, len(_norm(l.text)))
        dur = l.end - l.start
        prev_ok = next((x for x in reversed(lines[:i]) if x.status != "estimated"), None)
        if dur < 0.04 * chars or dur > 2.5 * chars + 4 or (prev_ok and l.start < prev_ok.start - 0.01):
            l.status = "estimated"

    i = 0
    while i < len(lines):
        if lines[i].status != "estimated":
            i += 1
            continue
        j = i
        while j < len(lines) and lines[j].status == "estimated":
            j += 1
        left = lines[i - 1].end if i > 0 else 0.0
        right = lines[j].start if j < len(lines) else duration
        if right <= left:
            right = left + 0.5 * (j - i)
        chars = [max(1, len(_norm(x.text))) for x in lines[i:j]]
        total = sum(chars)
        t = left
        for x, c in zip(lines[i:j], chars):
            span = (right - left) * c / total
            x.start, x.end = round(t, 3), round(t + span, 3)
            x.words = []
            x.confidence = min(x.confidence, 0.0)
            t += span
        i = j

    for x in lines:
        x.start, x.end = round(max(0.0, x.start), 3), round(min(duration, max(x.end, x.start)), 3)
