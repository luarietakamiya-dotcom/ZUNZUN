"""ほかのツール (ZUNZUN・MusicSync・ブラウザや Electron のアプリ) から使うためのローカル HTTP サーバー。

127.0.0.1 だけで待ち受けるので、同じ PC の外からは使えない。モデルは一度読み込んだら使い回す。
GPU は 1 つなので、ジョブは 1 本ずつ順番に処理する。

  GET    /health       状態
  GET    /manifest     plugin.json
  POST   /jobs         ジョブを登録 (multipart: audio か audio_path, lyrics, オプション) → Job
  GET    /jobs/{id}    進み具合と結果 → Job (status: queued / running / done / error / cancelled)
  DELETE /jobs/{id}    取り消す → Job
  POST   /align        /jobs と同じ入力で、終わるまで待って結果 (JobResult) を返す
  GET    /docs         説明 (OpenAPI。返す中身の形も書いてある)
"""

from __future__ import annotations

import json
import os
import queue
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Literal

# エンドポイントの引数・戻り値の型は FastAPI が型注釈 (from __future__ import annotations で文字列になる) から
# 読むので、関数の中ではなくファイルの先頭で読み込む・定義する
from fastapi import Request, UploadFile
from pydantic import BaseModel, Field

from . import __version__
from .aligner import Aligner, Cancelled
from .audio import CACHE_DIR
from .export import FORMATS, render

PLUGIN_JSON = Path(__file__).resolve().parent / "plugin.json"
LOCAL_ORIGINS = r"^(https?://(localhost|127\.0\.0\.1|\[::1\])(:\d+)?|null|file://.*|app://.*)$"
# インターネット上にあるが、使ってよいページ (ZUNZUN の公開版)。LYRICSYNC_PUBLIC_ORIGINS (カンマ区切り) で足せる。
# こうしたページからは、PC 上のパス (audio_path / vocals_path) の指定は受け付けず、音声ファイルを直接送ってもらう
# (公開ページから PC の中の好きなファイルを読ませる入口にしないため)。
PUBLIC_ORIGINS = tuple(dict.fromkeys(
    ["https://luarietakamiya-dotcom.github.io"]
    + [o.strip().rstrip("/") for o in os.environ.get("LYRICSYNC_PUBLIC_ORIGINS", "").split(",") if o.strip()]))
KEEP_FINISHED = 50  # 終わったジョブを覚えておく数 (古いものから忘れる)


def allowed_origin_regex() -> str:
    public = "|".join(re.escape(o) for o in PUBLIC_ORIGINS)
    return LOCAL_ORIGINS if not public else f"(?:{LOCAL_ORIGINS})|^(?:{public})$"


# ---------------------------------------------------------------------- 返す中身の形 (OpenAPI に載る)

JobStatus = Literal["queued", "running", "done", "error", "cancelled"]
LineStatus = Literal["ok", "low", "estimated", "interlude"]


class WordOut(BaseModel):
    text: str = Field(description="単語 (日本語はおおむね 1〜2 文字)")
    start: float = Field(description="始まり (秒)")
    end: float = Field(description="終わり (秒)")
    prob: float = Field(description="Whisper の自信 (0〜1)")


class LineOut(BaseModel):
    index: int = Field(description="行番号 (0 始まり)。ZUNZUN / JIZURA の lineTimes のキーと同じ数え方 (間奏の行も数える)")
    text: str = Field(description="表示する歌詞 (記号を取り除いたもの)。間奏の行は ''")
    start: float = Field(description="行の始まり (秒)")
    end: float = Field(description="行の終わり (秒)")
    confidence: float = Field(description="自信 (0〜1)")
    status: LineStatus = Field(description="ok: 問題なし / low: 自信が低い / estimated: 合わせられず前後から推定 / interlude: 間奏")
    words: list[WordOut] = Field(description="単語ごとの時刻。多数決で置いた行・推定した行・間奏では空")


class ResultData(BaseModel):
    lines: list[LineOut]
    duration: float = Field(description="曲の長さ (秒)")
    language: str
    model: str = Field(description="使った Whisper のモデル")
    elapsed: float = Field(description="処理にかかった時間 (秒)")
    settings: dict[str, Any]
    review: list[int] = Field(description="人の確認が要る行の番号 (status が low / estimated の行)")


class JobResult(BaseModel):
    data: ResultData
    files: dict[str, str] = Field(
        description="頼んだ形式ごとの書き出し。キーは lrc / elrc (単語ごとの LRC) / srt / zunzun "
                    "(ZUNZUN の lyrics.timing に入れる JSON の文字列)")


class Job(BaseModel):
    id: str
    status: JobStatus = Field(description="queued: 順番待ち / running: 処理中 / done: 完了 (result が入る) / "
                                          "error: 失敗 (error が入る) / cancelled: 取り消した")
    progress: float = Field(description="進み具合 (0〜1)")
    message: str = Field(description="いま何をしているか (日本語)")
    created: float = Field(description="登録した時刻 (UNIX 秒)")
    cancel_requested: bool = Field(description="取り消しを頼まれた (処理中なら、次の区切りで止まる)")
    result: JobResult | None = Field(description="status が done のときだけ入る")
    error: str | None = Field(description="status が error のときだけ入る")


class Health(BaseModel):
    ok: bool
    name: str
    version: str
    device: str
    gpu: str | None
    model: str
    model_loaded: bool = Field(description="モデルを読み込み済みか (False なら最初のジョブは読み込みの分だけ遅い)")
    queued: int = Field(description="順番待ちのジョブの数")
    running: str | None = Field(description="処理中のジョブの id")


# ---------------------------------------------------------------------- ジョブ


class JobRunner:
    def __init__(self, aligner: Aligner):
        self.aligner = aligner
        self.jobs: dict[str, dict] = {}
        self.q: queue.Queue = queue.Queue()
        self.running: str | None = None
        self.lock = threading.Lock()
        threading.Thread(target=self._loop, daemon=True).start()

    def submit(self, params: dict) -> str:
        jid = uuid.uuid4().hex[:12]
        with self.lock:
            self.jobs[jid] = {"id": jid, "status": "queued", "progress": 0.0, "message": "順番待ち",
                              "created": time.time(), "cancel_requested": False, "result": None, "error": None}
            self._forget_old()
        self.q.put((jid, params))
        return jid

    def cancel(self, jid: str) -> dict:
        """順番待ちならすぐ取り消す。処理中なら取り消しを頼み、次の区切りで止まる。終わったものはそのまま。"""
        with self.lock:
            job = self.jobs[jid]
            if job["status"] == "queued":
                job.update(status="cancelled", cancel_requested=True, message="取り消しました")
            elif job["status"] == "running":
                job.update(cancel_requested=True, message="取り消し中…")
            return dict(job)

    def busy(self) -> tuple[int, dict | None]:
        """(順番待ちの数, 処理中のジョブ)。タスクトレイの表示用。"""
        with self.lock:
            queued = sum(1 for j in self.jobs.values() if j["status"] == "queued")
            cur = dict(self.jobs[self.running]) if self.running in self.jobs else None
        return queued, cur

    def _forget_old(self) -> None:
        done = sorted((j for j in self.jobs.values() if j["status"] in ("done", "error", "cancelled")),
                      key=lambda j: j["created"])
        for j in done[:max(0, len(done) - KEEP_FINISHED)]:
            del self.jobs[j["id"]]

    def _loop(self):
        while True:
            jid, p = self.q.get()
            job = self.jobs.get(jid)
            try:
                if job is None or job["status"] == "cancelled":
                    continue
                job["status"], self.running = "running", jid

                def progress(frac, msg, job=job):
                    if not job["cancel_requested"]:
                        job["progress"], job["message"] = round(float(frac), 3), msg

                res = self.aligner.align(p["audio_path"], p["lyrics"], source=p["source"],
                                         language=p["language"], separate=p["separate"],
                                         vocals_path=p["vocals_path"], mms=p["mms"], progress=progress,
                                         cancel=lambda job=job: job["cancel_requested"])
                job["result"] = {"data": res.to_dict(),
                                 "files": {f: render(res, f) for f in p["formats"] if f != "json"}}
                job["status"] = "done"
            except Cancelled:
                job.update(status="cancelled", message="取り消しました")
            except Exception as e:  # ホストに理由を返す
                job["status"], job["error"] = "error", f"{type(e).__name__}: {e}"
            finally:
                self.running = None
                for tmp in p.get("cleanup", []):
                    Path(tmp).unlink(missing_ok=True)
                try:
                    self.aligner._free_gpu()
                except Exception:
                    pass


# ---------------------------------------------------------------------- アプリ


def create_app(model: str = "large-v3", device: str = "auto"):
    from fastapi import FastAPI, File, Form, HTTPException
    from fastapi.middleware.cors import CORSMiddleware

    app = FastAPI(title="LyricSync", version=__version__,
                  description="歌詞の自動タイミング合わせ。POST /jobs で頼み、GET /jobs/{id} で進み具合と結果を見る。")
    allowed = allowed_origin_regex()
    # allow_private_network: Chrome の Private Network Access。インターネット上のページ (公開版) が PC の中のサーバーと
    # 話すときの事前確認 (Access-Control-Request-Private-Network) に許可を返す
    app.add_middleware(CORSMiddleware, allow_origin_regex=allowed, allow_methods=["*"], allow_headers=["*"],
                       allow_private_network=True)

    @app.middleware("http")
    async def allowed_pages_only(request, call_next):
        # multipart の POST はブラウザの事前確認 (preflight) なしで送れるので、CORS だけでは
        # 外部サイトのページから「処理を始めさせる」ことは防げない。Origin が付いていて許可していないページなら断る。
        from fastapi.responses import JSONResponse

        origin = request.headers.get("origin")
        if origin is not None and not re.match(allowed, origin):
            return JSONResponse({"detail": "このサーバーは同じ PC 上のツールと許可したページからだけ使えます"},
                                status_code=403)
        return await call_next(request)

    def from_public_page(request) -> bool:
        return request.headers.get("origin", "").rstrip("/") in PUBLIC_ORIGINS

    runner = JobRunner(Aligner(model, device))
    app.state.runner = runner

    async def _params(request, audio, audio_path, vocals, vocals_path, lyrics, source, language, separate, formats,
                      mms=False):
        if from_public_page(request) and (audio_path or vocals_path):
            raise HTTPException(403, "公開ページからは PC 上のパスを指定できません。audio / vocals にファイルを送ってください")
        cleanup = []
        upload_dir = CACHE_DIR / "uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)

        async def save(f: UploadFile) -> str:
            dst = upload_dir / f"{uuid.uuid4().hex}{Path(f.filename or 'a.wav').suffix}"
            dst.write_bytes(await f.read())
            cleanup.append(str(dst))
            return str(dst)

        if audio is not None:
            audio_path = await save(audio)
        if not audio_path or not Path(audio_path).exists():
            raise HTTPException(400, "audio (ファイル) か audio_path (このPC上のパス) が必要です")
        if vocals is not None:
            vocals_path = await save(vocals)
        fmts = [f.strip() for f in formats.split(",") if f.strip()]
        bad = [f for f in fmts if f not in FORMATS]
        if bad:
            raise HTTPException(400, f"知らない形式: {bad}")
        if not lyrics.strip():
            raise HTTPException(400, "lyrics が空です")
        return {"audio_path": audio_path, "vocals_path": vocals_path or None, "lyrics": lyrics,
                "source": source, "language": None if language == "auto" else language,
                "separate": separate, "mms": bool(mms), "formats": fmts, "cleanup": cleanup}

    form = dict(
        audio=File(None, description="曲のファイル (公開ページからはこちら)"),
        audio_path=Form(None, description="このPC上の曲のパス (同じPCのツールだけ)"),
        vocals=File(None, description="ボーカルのステム (任意。渡すと分離を飛ばせて精度も上がる)"),
        vocals_path=Form(None, description="このPC上のボーカルのステムのパス (同じPCのツールだけ)"),
        lyrics=Form(..., description="歌詞 (テキスト / LRC / SRT)"),
        source=Form("auto", description="auto / text / lrc / srt"),
        language=Form("ja", description="言語コード。auto で自動判定"),
        separate=Form(True, description="ボーカル分離をするか"),
        formats=Form("lrc,elrc,srt,zunzun", description="書き出す形式 (カンマ区切り)"),
        mms=Form(False, description="合わせにくい行の多数決に MMS も使う (英語の掛け声などが合いやすくなる)。"
                                    "MMS のモデルは CC-BY-NC 4.0 (非商用) なので既定では使わない"),
    )

    def get_job(jid: str) -> dict:
        if jid not in runner.jobs:
            raise HTTPException(404, "そのジョブはありません")
        return runner.jobs[jid]

    @app.get("/health", response_model=Health)
    def health():
        import torch

        queued, cur = runner.busy()
        return {"ok": True, "name": "lyricsync", "version": __version__, "device": runner.aligner.device,
                "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                "model": runner.aligner.model_name, "model_loaded": runner.aligner._model is not None,
                "queued": queued, "running": cur["id"] if cur else None}

    @app.get("/manifest")
    def manifest():
        return json.loads(PLUGIN_JSON.read_text(encoding="utf-8"))

    @app.post("/jobs", response_model=Job, summary="ジョブを登録する")
    async def submit(request: Request, audio: UploadFile | None = form["audio"],
                     audio_path: str | None = form["audio_path"],
                     vocals: UploadFile | None = form["vocals"], vocals_path: str | None = form["vocals_path"],
                     lyrics: str = form["lyrics"], source: str = form["source"], language: str = form["language"],
                     separate: bool = form["separate"], formats: str = form["formats"],
                     mms: bool = form["mms"]):
        p = await _params(request, audio, audio_path, vocals, vocals_path, lyrics, source, language, separate, formats,
                          mms)
        return runner.jobs[runner.submit(p)]

    @app.get("/jobs/{jid}", response_model=Job, summary="進み具合と結果を見る")
    def job(jid: str):
        return get_job(jid)

    @app.delete("/jobs/{jid}", response_model=Job, summary="取り消す",
                description="順番待ちならすぐ cancelled になる。処理中なら cancel_requested が true になり、"
                            "次の区切りで止まって cancelled になる (Whisper の 1 回の呼び出しの途中では止まらないので、"
                            "十数秒かかることがある)。終わったジョブはそのまま返す。")
    def cancel(jid: str):
        get_job(jid)
        return runner.cancel(jid)

    @app.post("/align", response_model=JobResult, summary="終わるまで待って結果を返す",
              responses={409: {"description": "取り消された"}, 500: {"description": "失敗"}})
    async def align(request: Request, audio: UploadFile | None = form["audio"],
                    audio_path: str | None = form["audio_path"],
                    vocals: UploadFile | None = form["vocals"], vocals_path: str | None = form["vocals_path"],
                    lyrics: str = form["lyrics"], source: str = form["source"], language: str = form["language"],
                    separate: bool = form["separate"], formats: str = form["formats"],
                     mms: bool = form["mms"]):
        import asyncio

        p = await _params(request, audio, audio_path, vocals, vocals_path, lyrics, source, language, separate, formats,
                          mms)
        jid = runner.submit(p)
        while runner.jobs[jid]["status"] in ("queued", "running"):
            await asyncio.sleep(0.25)
        j = runner.jobs[jid]
        if j["status"] == "cancelled":
            raise HTTPException(409, "取り消されました")
        if j["status"] == "error":
            raise HTTPException(500, j["error"])
        return j["result"]

    return app


def run(port: int = 8765, model: str = "large-v3", device: str = "auto") -> None:
    import uvicorn

    print(f"LyricSync サーバー: http://127.0.0.1:{port}  (Ctrl+C で終了)")
    uvicorn.run(create_app(model, device), host="127.0.0.1", port=port, log_level="warning")


def start_in_thread(port: int = 8765, model: str = "large-v3", device: str = "auto"):
    """サーバーを別のスレッドで動かす (タスクトレイ用)。(uvicorn.Server, JobRunner) を返す。
    止めるときは server.should_exit = True。"""
    import uvicorn

    app = create_app(model, device)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", log_config=None))
    threading.Thread(target=server.run, daemon=True).start()
    return server, app.state.runner
