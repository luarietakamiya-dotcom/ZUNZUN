"""歌詞テキストの読み取り。

行番号を ZUNZUN / JIZURA と一致させるため、ZUNZUN の src/core/lyrics/parse.ts
(parseLyrics / stripBracketNotes / srtToLrc。元は 852wa/JIZURA の J.parseLyrics, MIT License)
と同じ順序・同じ条件で処理する。LRC の並べ方は 2026-11-08 の版 (ZUNZUN 071e582、JIZURA 0.10.1) に合わせた。ここで付けた行番号がそのまま
Project JSON の lyrics.timing.lineTimes / lineEnds のキーになる。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

TIME_TAG = re.compile(r"^\[(\d+):(\d+(?:[.:]\d+)?)\]")
META_TAG = re.compile(r"^\[(ti|ar|al|by|offset):(.*)\]$", re.I)
INTERLUDE = re.compile(
    r"^\[\s*(間奏|间奏|interlude|instrumental|inst|간주)(?:\s*[:：]?\s*(\d+(?:\.\d+)?)\s*(?:s|sec|秒|초)?)?\s*\]$",
    re.I,
)
SRT_TIME = re.compile(
    r"(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})\s*-->\s*(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})"
)


@dataclass
class LyricLine:
    index: int
    """ZUNZUN の lineTimes のキー (0 始まり)"""
    text: str
    """表示する歌詞 (記号を取り除いたもの)。間奏の行は ''"""
    src: int
    """元の入力の何行目から来たか"""
    lrc: float | None = None
    interlude: bool = False
    secs: float | None = None
    manual: list[str] | None = None
    gap_before: bool = False


@dataclass
class ParsedLyrics:
    lines: list[LyricLine]
    meta: dict[str, str] = field(default_factory=dict)

    @property
    def sung(self) -> list[LyricLine]:
        return [l for l in self.lines if not l.interlude and l.text]


def strip_bracket_notes(raw: str) -> str:
    """[Verse 1] [サビ] のような見出しを取り除く。タイムタグ・メタ情報・間奏は残す。"""
    out = []
    for row in str(raw or "").replace("\r", "").split("\n"):
        s0 = row.strip()
        if not s0 or s0.startswith("#") or META_TAG.match(s0):
            out.append(row)
            continue
        tags, s = "", s0
        while m := TIME_TAG.match(s):
            tags += m.group(0)
            s = s[len(m.group(0)):]
        s = s.strip()
        if INTERLUDE.match(s) or "[" not in s:
            out.append(row)
            continue
        rest = re.sub(r"\s{2,}", " ", re.sub(r"\[[^\]]*\]", " ", s)).strip()
        out.append(tags + rest if rest else "")
    return "\n".join(out)


def parse_lyrics(raw: str) -> ParsedLyrics:
    lines: list[LyricLine] = []
    meta: dict[str, str] = {}
    pending_gap = False
    rows = str(raw or "").replace("\r", "").split("\n")
    for ri, row in enumerate(rows):
        s0 = row.strip()
        if not s0:
            if lines:
                pending_gap = True
            continue
        if s0.startswith("#"):
            continue
        if mm := META_TAG.match(s0):
            meta[mm.group(1).lower()] = mm.group(2).strip()
            continue
        s, times = s0, []
        while m := TIME_TAG.match(s):
            times.append(int(m.group(1)) * 60 + float(m.group(2).replace(":", ".")))
            s = s[len(m.group(0)):]
        s = s.strip()

        if im := INTERLUDE.match(s):
            secs = float(im.group(2)) if im.group(2) else None
            for t in times or [None]:
                lines.append(LyricLine(0, "", ri, t, True, secs, None, pending_gap))
            pending_gap = False
            continue

        bar = s.find("|")
        if bar >= 0:
            s = s[:bar].strip()
        # JIZURA と同じ条件 (全角の「！」はキメにしない)
        if len(s) > 1 and s.endswith("!"):
            s = s[:-1].strip()
        s = re.sub(r"\*([^*]+)\*", r"\1", s)
        manual = None
        if "/" in s:
            manual = [x.strip() for x in s.split("/") if x.strip()]
            latin = any(re.search(r"[A-Za-z]", x) for x in manual)
            s = (" " if latin else "").join(manual)
        if not s:
            continue
        for t in times or [None]:
            lines.append(LyricLine(0, s, ri, t, False, None, manual, pending_gap))
        pending_gap = False

    if any(l.lrc is not None for l in lines):
        # LRC は時刻の順に並べる。時刻のない行 (間奏・手で足した行) は、書いた位置 (直前の時刻つきの行のすぐ後ろ) に残す。
        # ZUNZUN の parse.ts (2026-11-08、JIZURA 0.10.1 に合わせた版) と同じ計算 (それより前は末尾に回していた)
        key, k, keys = -1.0, 0, []
        for l in lines:
            if l.lrc is not None:
                key, k = l.lrc, 0
                keys.append(l.lrc)
            else:
                k += 1
                keys.append(key + 1e-6 * k)
        order = sorted(range(len(lines)), key=lambda i: keys[i])  # 安定ソート (JS と同じ)
        lines = [lines[i] for i in order]
    for i, l in enumerate(lines):
        l.index = i
    return ParsedLyrics(lines, meta)


def srt_to_lrc(raw: str) -> str:
    entries = []
    blocks = re.split(r"\n\s*\n", str(raw or "").lstrip("﻿ \t\r\n").replace("\r", ""))
    for block in blocks:
        rows = block.split("\n")
        ti = next((i for i, r in enumerate(rows) if SRT_TIME.search(r)), -1)
        if ti < 0:
            continue
        g = SRT_TIME.search(rows[ti]).groups()
        start = int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3].ljust(3, "0")) / 1000
        text = "/".join(t for t in (re.sub(r"<[^>]*>", "", r).strip() for r in rows[ti + 1:]) if t)
        if text:
            entries.append((start, text))
    entries.sort(key=lambda e: e[0])
    return "\n".join(f"[{int(s // 60):02d}:{s % 60:06.3f}]{t}" for s, t in entries)


def read_lyrics(text: str, source: str = "auto") -> ParsedLyrics:
    """source: 'text' | 'lrc' | 'srt' | 'auto'"""
    if source == "auto":
        source = "srt" if SRT_TIME.search(text or "") else "text"
    if source == "srt":
        text = srt_to_lrc(text)
    return parse_lyrics(strip_bracket_notes(text))
