"""音声の読み込みとボーカル分離 (Demucs)。分離結果は音源の sha256 ごとにキャッシュする。"""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
from pathlib import Path

import numpy as np
import soundfile as sf

CACHE_DIR = Path(os.environ.get("LYRICSYNC_HOME", Path.home() / ".lyricsync")) / "cache"

_demucs_models: dict = {}


def ffmpeg_exe() -> str:
    exe = os.environ.get("LYRICSYNC_FFMPEG") or shutil.which("ffmpeg")
    if not exe:
        raise RuntimeError("ffmpeg が見つかりません。PATH に入れるか LYRICSYNC_FFMPEG で場所を指定してください。")
    return exe


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_audio(path: str | Path, sr: int, channels: int = 1) -> np.ndarray:
    """どんな形式でも ffmpeg で float32 にする。戻り値は (channels, samples)。"""
    cmd = [ffmpeg_exe(), "-nostdin", "-v", "error", "-i", str(path),
           "-f", "f32le", "-ac", str(channels), "-ar", str(sr), "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).reshape(-1, channels).T.copy()


def separate_vocals(path: str | Path, model_name: str = "htdemucs", device: str = "cuda",
                    log=print, callback=None) -> Path:
    """ボーカルだけを取り出した wav (44.1kHz/モノラル) のパスを返す。

    callback: 分離の途中で呼ばれる (Demucs の区切りごと)。例外を投げれば分離を止められる (取り消し用)。
    """
    sha = file_sha256(path)
    out = CACHE_DIR / sha[:16] / f"vocals_{model_name}.wav"
    if out.exists():
        log(f"ボーカル分離: キャッシュを使います ({out})")
        return out

    import torch
    from demucs.apply import apply_model
    from demucs.pretrained import get_model

    if model_name not in _demucs_models:
        m = get_model(model_name)
        m.eval()
        _demucs_models[model_name] = m
    model = _demucs_models[model_name]

    log(f"ボーカル分離中 ({model_name}) ...")
    wav = torch.from_numpy(load_audio(path, model.samplerate, 2))
    ref = wav.mean(0)
    mean, std = ref.mean(), ref.std() + 1e-8
    with torch.no_grad():
        sources = apply_model(model, ((wav - mean) / std)[None], device=device, split=True,
                              overlap=0.25, progress=False, callback=callback)[0]
    vocals = sources[model.sources.index("vocals")] * std + mean
    out.parent.mkdir(parents=True, exist_ok=True)
    sf.write(out, vocals.mean(0).cpu().numpy(), model.samplerate)
    return out


def envelope_db(y: np.ndarray, sr: int, hop_s: float = 0.01, win_s: float = 0.03) -> np.ndarray:
    """短い窓の RMS (dB)。hop_s ごとに 1 値。歌い出しの吸着に使う。"""
    hop, win = int(sr * hop_s), int(sr * win_s)
    if y.ndim > 1:
        y = y.mean(0)
    n = max(1, (len(y) - win) // hop + 1)
    idx = np.arange(win)[None, :] + hop * np.arange(n)[:, None]
    frames = y[np.minimum(idx, len(y) - 1)]
    rms = np.sqrt((frames.astype(np.float64) ** 2).mean(1) + 1e-12)
    return 20 * np.log10(rms + 1e-9)
