"""LyricSync — 歌詞の自動タイミング合わせプラグイン。

ほかのツールから使う入口は 3 つ:
  - Python:  from lyricsync import Aligner; Aligner().align("song.wav", lyrics_text)
  - コマンド: python -m lyricsync align song.wav lyrics.txt
  - HTTP:    python -m lyricsync serve  →  http://127.0.0.1:8765  (plugin.json を参照)
"""

from .aligner import AlignedLine, Aligner, AlignResult, Cancelled, Word
from .export import FORMATS, render
from .lyrics import read_lyrics

__version__ = "1.2.0"
__all__ = ["Aligner", "AlignResult", "AlignedLine", "Cancelled", "Word", "FORMATS", "render", "read_lyrics", "__version__"]
