from pathlib import Path
import os, sys
root = Path(__file__).resolve().parent
scripts = Path(sys.executable).parent
os.environ["LYRICSYNC_HOME"] = str(root / "data")
os.environ["PATH"] = str(scripts) + os.pathsep + os.environ["PATH"]
os.environ["LYRICSYNC_FFMPEG"] = str(scripts / "ffmpeg.exe")
from lyricsync.tray import run_tray
run_tray()
